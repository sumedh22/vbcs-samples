define(['ojs/ojhtmlutils'], function(HtmlUtils) {
  'use strict';

  var PageModule = function PageModule() {};
  
  PageModule.prototype.getConfig = function() {
    const viewStr = '<div> Sample <b>text</b> from <i>module function.</i></div>'
    return {
      view: HtmlUtils.stringToNodeArray(viewStr),
      data: {
      }
    }
  }
  return PageModule;
});