define(function() {
  'use strict';

  return {
  "shell_header_title" : "My Application",
  "shell_footer_about_link" : "About",
  "shell_footer_copyright" : "Created with Visual Builder, Copyright © 2019",
  "shell_title_tooltip" : "Application Name",
  "shell_sign_out" : "Sign Out"
};
});