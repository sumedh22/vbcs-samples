define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  return PageModule;
});
